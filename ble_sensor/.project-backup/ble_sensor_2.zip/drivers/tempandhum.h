﻿#ifndef TEMPANDHUM_H
#define TEMPANDUHM_H

#include <i2c_simple_master.h>

#define TEMPANDHUM_I2C_ADDR	0x5F

//register addresses
#define TEMPANDHUM_WHO_AM_I											0x0F

#define TEMPANDHUM_TEMP_OUT_L										0x2A
#define TEMPANDHUM_TEMP_OUT_H										0x2B



#define TEMPANDHUM_HUMIDITY_OUT_L 									0x28
#define TEMPANDHUM_HUMIDITY_OUT_H 									0x29

#define TEMPANDHUM_AV_CONF                                          0x10
#define TEMPANDHUM_CTRL_REG1                                        0x20
#define TEMPANDHUM_CTRL_REG2                                        0x21
#define TEMPANDHUM_CTRL_REG3                                        0x22

#define TEMPANDHUM_STATUS_REG                                       0x27 // bit0 - temp data available, bit1 - hum data available

//default values

#define TEMPANDHUM_AV_CONF_DEFAULT_VALUE							0x1B
#define TEMPANDHUM_CTRL_REG1_DEFAULT_VALUE                          0x67 
#define TEMPANDHUM_CTRL_REG2_DEFAULT_VALUE                          0x00
#define TEMPANDHUM_CTRL_REG3_DEFAULT_VALUE                          0x00




void tempandhum_init(void);

void tempandhum_test(void);

float temphum_get_temp_data(void);

#endif