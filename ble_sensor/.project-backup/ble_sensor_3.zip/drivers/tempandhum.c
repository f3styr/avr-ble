﻿#include "tempandhum.h"
#include <util/delay.h>

void tempandhum_init(void)
{
	_delay_ms(100);
	i2c_write1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_AV_CONF, TEMPANDHUM_AV_CONF_DEFAULT_VALUE);
	_delay_ms(10);
	i2c_write1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_CTRL_REG1,TEMPANDHUM_CTRL_REG1_DEFAULT_VALUE);	
	_delay_ms(10);
	i2c_write1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_CTRL_REG2, TEMPANDHUM_CTRL_REG2_DEFAULT_VALUE);	
	_delay_ms(10);
	i2c_write1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_CTRL_REG3, TEMPANDHUM_CTRL_REG3_DEFAULT_VALUE);
	_delay_ms(10);
	
	_delay_ms(1000);
	printf("\n\rTEMPANDHUM_AV_CONF = %x\r\n", i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_AV_CONF));
	printf("\n\rTEMPANDHUM_CTRL_REG1 = %x\r\n", i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_CTRL_REG1));
	printf("\n\rTEMPANDHUM_CTRL_REG2 = %x\r\n", i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_CTRL_REG2));
	
	print_status();
}



void tempandhum_test(void)
{

return;
/*
	for(int8_t i = 0x30; i <= 0x3f; i++){
		printf("%x\r\n", i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, i) )	;
	
	} 
*/
	//int8_t temp_t = i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_WHO_AM_I);
	
	i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, 0xB0);
	_delay_ms(100);
	

	
	for(int i = 0x30; i <= 0x3F; i++){
		printf("%d\r\n", i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, i));
	}
	

	_delay_ms(10);
	
	int8_t hum_l = i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_HUMIDITY_OUT_L);
	int8_t hum_h = i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_HUMIDITY_OUT_H);

	int8_t temp_l = i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_TEMP_OUT_L);
	int8_t temp_h = i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_TEMP_OUT_H);	

	_delay_ms(10);

	

	
	_delay_ms(5000);
	printf("registers - %x, %x, hum - %x, %x \r\n", temp_l, temp_h, hum_l, hum_h);
	print_status();
}

void print_status()
{
	
	int8_t status = i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_STATUS_REG);
	printf("status - %d\r\n", status);
}


float temphum_get_temp_data(void)
{

		
	int16_t temperature;
	int8_t temp_l = i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_TEMP_OUT_L);
	int8_t temp_h = i2c_read1ByteRegister(TEMPANDHUM_I2C_ADDR, TEMPANDHUM_TEMP_OUT_H);

	temperature = temp_h;
	temperature <<= 8;
	temperature |= temp_l;

	float temp1;
	float temp2;
	
	temp1 = ( temperature >> 4 );
	temp2 = ( temperature & 0x000F );
	

		    
	return temp1 * 0.8046 + ( temp2 / 100.0 );
	
	
}
